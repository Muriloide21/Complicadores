if(True):
    x = 4
y=x # Se jogar para o inicio da linha agora funciona... :P
