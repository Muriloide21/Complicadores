x = 4
y = "Teste"
print(x)