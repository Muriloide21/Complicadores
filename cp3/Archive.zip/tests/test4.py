def f(x):
  y = x * x
  e = (m * c * c)
  if x > 0:
    return e
  else:
    return y
