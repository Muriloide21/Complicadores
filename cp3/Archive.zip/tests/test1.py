x = 4
x = 7
a = .1
c = 2.3
d = 0xa32B5
b = .1e-12 
c = a + b
print(y)
print('Teste') #Test
#Teste1
print('oi')
